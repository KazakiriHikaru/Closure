# WPJS

一个4年前用在WordPress上的“迅雷、快车、旋风URL加/解密”页面，包括

DownloadDEC TFQ.htm：界面（包含核心和输出的JavaScript）

DownloadDEC.js：核心

DownloadDECoutput.js：加密和解密输出

EOF
