/**
 * 
 */
package co.jp.any;

import co.jp.any.swing.component.JButtonTest;

/**
 * @author tozawa_h01
 *
 */
public class SwingMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//new JFrameTest();
		new JButtonTest();
	}

}
