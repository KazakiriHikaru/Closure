/**
 * 
 */
package facss.co.jp.java.src;

/**
 * @author PC User
 *
 */
public class BattleShipDto {
	
	
//	public List<BattleShipDto> battleShipList;
//	
//	public List<BattleShipDto> heavyCruiser;
//	
//	public List<BattleShipDto> lightCruiser;
//	
//	public List<BattleShipDto> destroyer;
	
	public String orgCode = "";
	
	public String orgName = "";
	
	public String abbreviation = "";
	
	public String orgCode1 = "";
	
	public String orgName1 = "";
	
	public String orgCode2;
	
	public String orgName2;

	public String orgCode3 = "";
	
	public String orgName3 = "";

	public String orgCode4;
	
	public String orgName4;

}
